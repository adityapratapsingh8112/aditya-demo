TrustShield Android - complete project (open as-is, nothing to copy)

OPTION A - get the APK without installing anything (GitHub):
 1. Create a free GitHub repo, upload ALL files of this zip (keep the .github folder).
 2. Open the Actions tab > "Build APK" > wait ~5 min > download artifact "TrustShield-apk" (contains app-debug.apk).
 3. Send app-debug.apk to your phone (WhatsApp/Drive), tap it, allow "Install unknown apps". The app installs like any other.

OPTION B - Android Studio: File > Open this folder > wait for sync > Build > Build APK(s). APK is in app/build/outputs/apk/debug/.

First launch: allow SMS + notifications, choose TrustShield as call-screening app, tap "Enable WhatsApp access".
Demo: Home > "Simulate scam attack". Profile tab: name, trusted contact, per-shield switches, safety level, share alert.

IF SMS / CALLS ARE NOT DETECTED (read this first)
 1. Open the app: the Setup card on Home must show 6/6 ready. Tap "Fix" on every red item.
 2. Installed from an APK (not Play Store)? Android 13+ blocks SMS + notification access until you do:
    Settings > Apps > TrustShield > (three dots) > "Allow restricted settings". Then tap Fix again.
 3. Xiaomi/Oppo/Vivo/Realme/OnePlus: also turn ON "Autostart" and set battery to "No restrictions" for TrustShield.
 4. Real SMS test: send the scam text from ANOTHER phone to this phone. A notification appears within a second.
    Emulator: adb emu sms send 5551234 "URGENT: SBI account blocked. Update KYC http://sbi-kyc.xyz"
 5. Real call test: call from a number that is NOT in your contacts. Unknown + foreign (+92...) numbers are silenced,
    140-series telemarketing and listed scam numbers are rejected. Numbers saved in contacts are never touched.
 6. WhatsApp: enable TrustShield in "Notification access", then message yourself from another number.
Limits: Android lets apps warn about SMS but not delete them; call audio and WhatsApp content cannot be blocked, only warned.
