package com.quantumquills.trustshield
import android.app.*; import android.content.Context; import android.os.*
import androidx.compose.runtime.*

data class Ev(val src: Int, val text: String, val score: Int, val verdict: String, val key: String)

/** One shared brain: SMS receiver, call screener, WhatsApp listener and QR scanner all report here. */
object Store {
    val feed = mutableStateListOf<Ev>()
    var auto by mutableStateOf(true)
    var lang by mutableStateOf("en"); var tick by mutableStateOf(0)
    var name by mutableStateOf(""); var contact by mutableStateOf(""); val srcOn = mutableStateListOf(true, true, true, true)
    fun load(c: Context) { val p = c.getSharedPreferences("ts", 0); name = p.getString("name", "")!!; contact = p.getString("contact", "")!!; lang = p.getString("lang", "en")!!; for (i in 0..3) srcOn[i] = p.getBoolean("s$i", true) }
    fun save(c: Context) { val e = c.getSharedPreferences("ts", 0).edit().putString("name", name).putString("contact", contact).putString("lang", lang); for (i in 0..3) e.putBoolean("s$i", srcOn[i]); e.apply() }
    fun t(i: Int) = Strings.t(lang, i)
    fun reason(k: String) = when (k) { "lookalike" -> 11; "urgency" -> 12; "keyword" -> 13; "shortener" -> 14; "spam" -> 15; "safe" -> 17; "secret" -> 35; "threat" -> 36; "money" -> 37; "apk" -> 38; "callback" -> 39; "spoof" -> 40; "foreign" -> 41; else -> 16 }

    fun handle(c: Context, src: Int, text: String, r: Scorer.Result) {
        if (!auto || !srcOn[src]) return
        val k = r.keys.firstOrNull() ?: "safe"
        Handler(Looper.getMainLooper()).post { feed.add(0, Ev(src, text, r.score, r.verdict, k)); if (feed.size > 50) feed.removeAt(feed.size - 1) }
        if (r.verdict != "allow") alert(c, t(18 + src), r.verdict, t(reason(k)))
    }
    private fun alert(c: Context, source: String, verdict: String, why: String) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ts", "TrustShield", NotificationManager.IMPORTANCE_HIGH))
        nm.notify(System.nanoTime().toInt(), Notification.Builder(c, "ts").setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle((if (verdict == "block") t(8) else t(9)) + " · " + source).setContentText(why).build())
    }
}
