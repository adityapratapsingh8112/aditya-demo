package com.quantumquills.trustshield
import android.content.*; import android.provider.Telephony; import android.service.notification.*; import android.telecom.*

class SmsReceiver : BroadcastReceiver() {          // auto-reads every incoming SMS
    override fun onReceive(c: Context, i: Intent) {
        for (m in Telephony.Sms.Intents.getMessagesFromIntent(i)) { val b = m.messageBody.orEmpty(); Store.handle(c, 0, b, Scorer.text(b)) }
    }
}
class ShieldCallService : CallScreeningService() {  // auto-rejects known scam numbers (number only, never call audio)
    override fun onScreenCall(d: Call.Details) {
        val n = d.handle?.schemeSpecificPart.orEmpty(); val r = Scorer.call(this, n); val bad = r.verdict == "block"
        respondToCall(d, CallResponse.Builder().setDisallowCall(bad).setRejectCall(bad).setSkipNotification(bad).setSilenceCall(r.verdict == "warn").build())
        Store.handle(this, 1, n, r)
    }
}
class ShieldNotificationListener : NotificationListenerService() {  // auto-reads WhatsApp / Telegram message notifications
    private val apps = setOf("com.whatsapp", "com.whatsapp.w4b", "org.telegram.messenger")
    override fun onNotificationPosted(s: StatusBarNotification) {
        if (s.packageName !in apps) return
        val t = s.notification.extras.getCharSequence("android.text")?.toString() ?: return
        Store.handle(this, 3, t, Scorer.text(t))
    }
}
