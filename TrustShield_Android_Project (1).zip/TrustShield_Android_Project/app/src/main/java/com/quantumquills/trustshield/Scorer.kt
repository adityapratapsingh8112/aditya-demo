package com.quantumquills.trustshield
// Rule engine v2 (mirrors the website): 12 signal families, English + Hindi, aware of genuine OTP messages.
object Scorer {
    data class Result(val score: Int, val keys: List<String>) {
        val verdict get() = if (score < 40) "block" else if (score < 70) "warn" else "allow"
    }
    private val I = RegexOption.IGNORE_CASE
    private val brands = mapOf("sbi" to listOf("sbi.co.in", "onlinesbi.sbi", "sbi.bank.in"), "hdfc" to listOf("hdfcbank.com"), "icici" to listOf("icicibank.com"),
        "axis" to listOf("axisbank.com"), "kotak" to listOf("kotak.com"), "pnb" to listOf("pnbindia.in"), "paytm" to listOf("paytm.com"), "phonepe" to listOf("phonepe.com"),
        "amazon" to listOf("amazon.in", "amazon.com"), "flipkart" to listOf("flipkart.com"), "irctc" to listOf("irctc.co.in"), "jio" to listOf("jio.com"),
        "airtel" to listOf("airtel.in"), "npci" to listOf("npci.org.in"), "uidai" to listOf("uidai.gov.in"))
    private val short = Regex("""^(bit\.ly|tinyurl\.com|t\.co|cutt\.ly|rb\.gy|is\.gd|goo\.gl|ow\.ly|tiny\.cc|shorturl\.at|s\.id|t\.ly|bitly\.com|rebrand\.ly)\z""")
    private val urlRx = Regex("""(https?://\S+|\b[\w-]+(?:\.[\w-]+)*\.(?:com|in|net|org|co|io|me|ly|gl|xyz|top|click|link|info|icu|vip|shop|site|online|live|buzz|club|cc|tk|ml|ga|cf|gq|support|help|work|cam|fit|rest|cfd|sbs|monster|today|win|bid|app|page|store|tech|pro|biz|us|uk|ru|cn)\b(?:[/?#]\S*)?)""", I)
    private val riskTld = Regex("""\.(xyz|top|click|link|info|icu|vip|shop|site|online|live|buzz|club|cc|tk|ml|ga|cf|gq|support|help|work|cam|fit|rest|cfd|sbs|monster|today|win|bid)\z""")
    private val ipRx = Regex("""^\d{1,3}(\.\d{1,3}){3}\z""")
    private val negShare = Regex("""(do not|don't|dont|never|मत)[^.]{0,40}(share|disclose|give|बताएं|बताना)[^.]*\.?""", I)
    private val secretRx = Regex("""(share|send|tell|give|provide|forward|read out)[^.]{0,40}\b(otp|pin|cvv|password)\b|\b(otp|pin|cvv)\b[^.]{0,25}\b(share|send|tell|give)\b|anydesk|teamviewer|quicksupport|screen ?shar|remote access|(do not|don't) tell (anyone|your family)|stay on (the )?(call|video)|(ओटीपी|पिन)[^.]{0,20}(बताएं|भेजें|शेयर)""", I)
    private val threatRx = Regex("""arrest|\bcbi\b|narcotics|drugs? (found|in your)|customs (officer|department)|warrant|legal action|\bfir\b|police|court notice|sim (card )?(will be )?(blocked|deactivated|disconnected)|(electricity|power|connection|gas)[^.]{0,30}(disconnect|cut|stop)|disconnect(ed|ion)|account (will be |has been |is )?(blocked|frozen|closed|suspended)|खाता (बंद|ब्लॉक)|बिजली[^।.]{0,20}(कट|बंद)|गिरफ""", I)
    private val moneyRx = Regex("""(earn|income|salary|make)[^.]{0,30}\d[\d,]*\s?(rs\.?|₹|inr)?[^.]{0,12}(per|/|a)\s?(day|hour|week|daily)|₹\s?\d[\d,]*\s?(per|/)\s?(day|hour|task)|part[- ]time|work from home|like (and )?subscribe|(youtube|instagram) (videos|likes|reels)|double your (money|investment)|guaranteed (return|profit|income)|100% (profit|return|guarantee)|daily profit|trading (group|tips|signals)|घर बैठे कमा""", I)
    private val apkRx = Regex("""\.apk\b|(install|download)[^.]{0,20}(app|apk)\b|apk file""", I)
    private val callRx = Regex("""(call|contact|whatsapp|dial|reach|कॉल)[^.]{0,30}[6-9]\d{4}[\s-]?\d{5}\b|[6-9]\d{4}[\s-]?\d{5}[^.]{0,20}(call|contact|whatsapp)|wa\.me/|t\.me/|telegram""", I)
    private val keywordRx = Regex("""\bkyc\b|pan (card )?(update|verif|expire|link)|aadhaar (update|verif|link)|\bprize\b|lottery|lucky draw|you (have )?won|congratulations|\bclaim\b|\brefund\b|cashback|reward points?|gift card|free (gift|recharge|iphone)|(delivery|customs|processing|registration|clearance|redelivery) (fee|charges?)|pay (a )?(small )?(fee|charge)|इनाम|लॉटरी|केवाईसी|रिफंड|बधाई""", I)
    private val urgencyRx = Regex("""urgent|immediately|right now|tonight|(by|before|only) today|within \d+ ?(hours?|hrs?|mins?|minutes)|expire|last chance|final notice|act now|asap|turant|jaldi|तुरंत|आज ही|अभी|जल्दी""", I)

    private fun fin(m: Map<String, Int>): Result {
        var s = 100 + m.values.sum(); if (m.size > 1) s -= 12 * (m.size - 1)
        return Result(s.coerceIn(0, 100), m.keys.toList())
    }
    private fun finL(sg: List<Pair<String, Int>>) = Result((100 + sg.sumOf { it.second }).coerceIn(0, 100), sg.map { it.first })

    fun text(t: String): Result {
        val m = linkedMapOf<String, Int>()
        if (secretRx.containsMatchIn(t.replace(negShare, ""))) m["secret"] = -40
        if (threatRx.containsMatchIn(t)) m["threat"] = -25
        if (moneyRx.containsMatchIn(t)) m["money"] = -45
        if (apkRx.containsMatchIn(t)) m["apk"] = -35
        if (callRx.containsMatchIn(t)) m["callback"] = -20
        for (u in urlRx.findAll(t).map { it.value.trimEnd('.', ',', ')', '!') }) {
            val raw = u.replace(Regex("^https?://", I), "").split('/', '?', '#')[0]
            val host = raw.substringAfterLast('@').replace(Regex(":\\d+\\z"), "").lowercase()
            if (short.matches(host)) m["shortener"] = -25
            if ('@' in raw || ipRx.matches(host) || "xn--" in host || host.count { it == '-' } >= 3) m["spoof"] = -30
            if (riskTld.containsMatchIn(host)) m["tld"] = -20
            if (u.startsWith("http://", true)) m["nohttps"] = -8
            for ((b, ok) in brands) {
                val official = ok.any { host == it || host.endsWith(".$it") }
                if (!official && (host.contains(b) || Regex("\\b$b\\b", I).containsMatchIn(t)) && !short.matches(host)) m["lookalike"] = -35
            }
        }
        if (keywordRx.containsMatchIn(t)) m["keyword"] = -30
        if (urgencyRx.containsMatchIn(t)) m["urgency"] = -12
        return fin(m)
    }
    fun upi(uri: String): Result {
        val q = android.net.Uri.parse(uri); val sg = mutableListOf("unknown" to -20)
        if (Regex("refund|prize|cashback|reward|lottery|kyc|winner|gift", I).containsMatchIn(q.getQueryParameter("tn") ?: "")) sg += "keyword" to -25
        if ((q.getQueryParameter("am")?.toDoubleOrNull() ?: 0.0) >= 2000) sg += "amount" to -10
        if (Regex("""\d{5,}""").containsMatchIn(q.getQueryParameter("pa") ?: "")) sg += "vpa" to -7
        return finL(sg)
    }
    private val blocked = setOf("9876541234")   // demo community list; add numbers or load from your backend
    private fun inContacts(c: android.content.Context, n: String) = try {
        c.checkSelfPermission(android.Manifest.permission.READ_CONTACTS) == android.content.pm.PackageManager.PERMISSION_GRANTED &&
            c.contentResolver.query(android.net.Uri.withAppendedPath(android.provider.ContactsContract.PhoneLookup.CONTENT_FILTER_URI, android.net.Uri.encode(n)),
                arrayOf(android.provider.ContactsContract.PhoneLookup._ID), null, null, null)?.use { it.count > 0 } == true
    } catch (e: Exception) { false }
    /** Real call checks: contacts, TRAI 140 telemarketing series, community list, foreign/hidden numbers. */
    fun call(c: android.content.Context, number: String): Result {
        if (number.isBlank()) return finL(listOf("foreign" to -30, "unknown" to -20))
        if (inContacts(c, number)) return finL(emptyList())
        val sg = mutableListOf<Pair<String, Int>>()
        if (number.startsWith("140") || number.startsWith("+91140") || number.takeLast(10) in blocked) sg += "spam" to -45
        if (number.startsWith("+") && !number.startsWith("+91")) sg += "foreign" to -30
        sg += "unknown" to -20
        return finL(sg)
    }
}
