package com.quantumquills.trustshield
import android.Manifest; import android.app.role.RoleManager; import android.content.Intent; import android.net.Uri
import android.os.Bundle; import android.provider.Settings
import androidx.activity.ComponentActivity; import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.*; import androidx.compose.foundation.layout.*; import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items; import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*; import androidx.compose.runtime.*
import androidx.compose.ui.*; import androidx.compose.ui.draw.clip; import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke; import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight; import androidx.compose.ui.text.style.TextAlign; import androidx.compose.ui.unit.*; import androidx.compose.ui.draw.drawBehind; import androidx.compose.ui.geometry.Offset; import androidx.compose.foundation.shape.CircleShape; import androidx.compose.foundation.text.KeyboardOptions; import androidx.compose.ui.text.input.KeyboardType
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import kotlinx.coroutines.delay; import kotlinx.coroutines.launch

val Navy = Color(0xFFF6F9FB); val CardC = Color(0xFFFFFFFF); val Blue = Color(0xFF0F9488); val Green = Color(0xFF0F9488); val Gold = Color(0xFFD97706); val Red = Color(0xFFD63A2F); val Ink = Color(0xFF0F172A)
// Same soft mint (top-left) + lavender (top-right) glow on near-white as the TrustShield website
fun Modifier.appBg(): Modifier = this.background(Color(0xFFF6F9FB)).drawBehind {
    drawRect(Brush.radialGradient(listOf(Color(0x3814A094), Color.Transparent), Offset(size.width * .1f, size.height * .06f), size.width * 1.1f))
    drawRect(Brush.radialGradient(listOf(Color(0x2B9678E6), Color.Transparent), Offset(size.width * .95f, size.height * .04f), size.width * .9f))
}
fun vc(v: String) = when (v) { "block" -> Red; "warn" -> Gold; else -> Green }
fun t(i: Int) = Store.t(i)

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestPermissions(arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.READ_CONTACTS), 1)
        val rm = getSystemService(RoleManager::class.java)
        if (!rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)) startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING), 2)
        Store.load(this); setContent { TrustApp() }
    }
    override fun onResume() { super.onResume(); Store.tick++ }
}

@Composable fun TrustApp() {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope(); var tab by remember { mutableStateOf(0) }
    val hero = if (!Store.auto) Color.Gray else vc(Store.feed.firstOrNull()?.verdict ?: "allow")
    val demo = listOf(
        { Store.handle(ctx, 0, "Hi, dinner at 8? - Meera", Scorer.text("Hi, dinner at 8? - Meera")) },
        { val m = "URGENT: SBI account blocked. Complete KYC within 24 hours http://sbi-kyc-update.xyz"; Store.handle(ctx, 0, m, Scorer.text(m)) },
        { Store.handle(ctx, 1, "+91 98765 41234", Scorer.call(ctx, "+919876541234")) },
        { val q = "upi://pay?pa=refund.help9918273@okbank&am=4999&tn=Refund"; Store.handle(ctx, 2, q, Scorer.upi(q)) },
        { val m = "Your parcel is held. Pay fee: bit.ly/3xParcel"; Store.handle(ctx, 3, m, Scorer.text(m)) })
    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, background = Navy, surface = CardC)) {
      Scaffold(modifier = Modifier.appBg(), containerColor = Color.Transparent, bottomBar = {
        NavigationBar(containerColor = CardC) { listOf("🛡" to 26, "👤" to 27).forEachIndexed { i, (e, l) -> NavigationBarItem(tab == i, { tab = i }, { Text(e, fontSize = 20.sp) }, label = { Text(t(l)) }) } } }) { pad ->
        if (tab == 1) ProfileScreen(pad) else
        LazyColumn(Modifier.fillMaxSize().padding(pad).statusBarsPadding().padding(horizontal = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            item { Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("TrustShield", Modifier.weight(1f), Ink, 22.sp, fontWeight = FontWeight.ExtraBold)
                listOf("en" to "EN", "hi" to "हि", "ta" to "த", "te" to "తె").forEach { (k, l) -> TextButton({ Store.lang = k; Store.save(ctx) }) { Text(l, color = if (Store.lang == k) Blue else Color.Gray) } } } }
            item { ShieldHero(hero)
                Text(t(if (Store.auto) 1 else 2), color = hero, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(t(0), color = Color.Gray, fontSize = 13.sp)
                Switch(Store.auto, { Store.auto = it }, Modifier.padding(8.dp)) }
            item { Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp)) {
                Stat(t(22), Store.feed.size, Blue); Stat(t(23), Store.feed.count { it.verdict != "allow" }, Gold); Stat(t(24), Store.feed.count { it.verdict == "block" }, Red) } }
            item { SetupCard() }
            item { Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), Arrangement.SpaceEvenly) {
                (18..21).forEach { Text("● " + t(it), color = if (Store.auto) Blue else Color.Gray, fontSize = 13.sp) } } }
            item { Button({ scope.launch { demo.forEach { it(); delay(2600) } } }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Blue)) { Text("⚡ " + t(4)) }
                Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp)) {
                    OutlinedButton({ GmsBarcodeScanning.getClient(ctx).startScan().addOnSuccessListener { b -> val v = b.rawValue.orEmpty()
                        Store.handle(ctx, 2, v, if (v.startsWith("upi://")) Scorer.upi(v) else Scorer.text(v)) } }, Modifier.weight(1f)) { Text(t(3)) }
                    OutlinedButton({ ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:1930"))) }, Modifier.weight(1f)) { Text(t(5)) } }
                TextButton({ ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }) { Text(t(25), color = Blue) }
                Spacer(Modifier.height(6.dp)) }
            if (Store.feed.isEmpty()) item { Text(t(6), color = Color.Gray, textAlign = TextAlign.Center, modifier = Modifier.padding(24.dp)) }
            items(Store.feed.take(8)) { e -> Row(Modifier.fillMaxWidth().padding(bottom = 8.dp).clip(RoundedCornerShape(14.dp)).background(CardC).height(IntrinsicSize.Min)) {
                Box(Modifier.width(6.dp).fillMaxHeight().background(vc(e.verdict)))
                Column(Modifier.weight(1f).padding(12.dp)) {
                    Text(t(18 + e.src) + " · " + e.text.take(44), color = Ink, fontSize = 13.sp)
                    Text(t(if (e.verdict == "allow") 17 else Store.reason(e.key)), color = Color.Gray, fontSize = 12.sp) }
                Text("${e.score}", Modifier.padding(12.dp), vc(e.verdict), 20.sp, fontWeight = FontWeight.ExtraBold) } }
            item { Text(t(7), color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(vertical = 16.dp)) }
        }
    } }
}
@Composable fun RowScope.Stat(label: String, n: Int, c: Color) = Column(Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(CardC).padding(12.dp), Arrangement.Center) {
    Text("$n", color = c, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold); Text(label, color = Color.Gray, fontSize = 11.sp) }

@Composable fun ShieldHero(color: Color) {
    val p by rememberInfiniteTransition(label = "p").animateFloat(0f, 1f, infiniteRepeatable(tween(2200)), label = "p")
    val c by animateColorAsState(color, tween(500), label = "c")
    Canvas(Modifier.size(210.dp)) {
        for (k in 0..1) { val q = (p + k * .5f) % 1f; drawCircle(c.copy(alpha = .4f * (1 - q)), size.minDimension / 2 * (.45f + .55f * q), style = Stroke(3.dp.toPx())) }
        val w = size.width
        drawPath(Path().apply { moveTo(w * .5f, w * .2f); lineTo(w * .74f, w * .29f); lineTo(w * .74f, w * .52f)
            cubicTo(w * .74f, w * .68f, w * .62f, w * .77f, w * .5f, w * .82f); cubicTo(w * .38f, w * .77f, w * .26f, w * .68f, w * .26f, w * .52f); lineTo(w * .26f, w * .29f); close() }, c)
        drawPath(Path().apply { moveTo(w * .4f, w * .5f); lineTo(w * .48f, w * .58f); lineTo(w * .62f, w * .42f) }, Color.White, style = Stroke(7.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

@Composable fun ProfileScreen(pad: PaddingValues) {
    val ctx = LocalContext.current
    val blocked = Store.feed.count { it.verdict == "block" }
    val level = if (blocked >= 3) "Gold" else if (blocked >= 1) "Silver" else "Bronze"
    val lc = when (level) { "Gold" -> Gold; "Silver" -> Color(0xFF6F8398); else -> Color(0xFFB0703C) }
    LazyColumn(Modifier.fillMaxSize().padding(pad).statusBarsPadding().padding(horizontal = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        item { Spacer(Modifier.height(24.dp))
            Box(Modifier.size(108.dp).border(4.dp, Blue, CircleShape).padding(6.dp).clip(CircleShape).background(Blue), Alignment.Center) {
                Text(Store.name.take(1).uppercase().ifEmpty { "T" }, color = Color.White, fontSize = 42.sp, fontWeight = FontWeight.ExtraBold) }
            Text(Store.name.ifEmpty { "TrustShield" }, color = Ink, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
            Text("🛡 " + t(33) + ": " + level + "  ·  " + t(34) + ": " + blocked, color = lc, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(vertical = 6.dp)) }
        item { OutlinedTextField(Store.name, { Store.name = it; Store.save(ctx) }, Modifier.fillMaxWidth().padding(top = 8.dp), label = { Text(t(28)) }, singleLine = true)
            OutlinedTextField(Store.contact, { Store.contact = it; Store.save(ctx) }, Modifier.fillMaxWidth().padding(vertical = 8.dp), label = { Text(t(29)) }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)) }
        item { Text(t(32), color = Ink, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp).fillMaxWidth())
            (0..3).forEach { i -> Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(t(18 + i), Modifier.weight(1f), Ink); Switch(Store.srcOn[i], { Store.srcOn[i] = it; Store.save(ctx) }) } } }
        item { Button({ val l = Store.feed.firstOrNull { it.verdict != "allow" }
                val msg = "TrustShield alert: " + (l?.text?.take(80) ?: "all clear") + " (" + (l?.score ?: 100) + "/100)"
                ctx.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Store.contact)).putExtra("sms_body", msg)) },
                Modifier.fillMaxWidth().padding(top = 16.dp)) { Text("📤 " + t(30)) } }
    }
}

data class Step(val label: String, val ok: Boolean, val fix: () -> Unit)
/** Live health-check: every switch Android needs before SMS / calls / WhatsApp can be read. Turns green as you fix each one. */
@Composable fun SetupCard() {
    val ctx = LocalContext.current; val act = ctx as ComponentActivity; Store.tick
    val perm = { p: String -> ctx.checkSelfPermission(p) == android.content.pm.PackageManager.PERMISSION_GRANTED }
    val ask = { p: String -> act.requestPermissions(arrayOf(p), 1) }
    val rm = ctx.getSystemService(RoleManager::class.java)
    val steps = listOf(
        Step("Read incoming SMS", perm(Manifest.permission.RECEIVE_SMS)) { ask(Manifest.permission.RECEIVE_SMS) },
        Step("Show alerts (notifications)", ctx.getSystemService(android.app.NotificationManager::class.java).areNotificationsEnabled()) { ask(Manifest.permission.POST_NOTIFICATIONS) },
        Step("Screen incoming calls", rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)) { act.startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING), 2) },
        Step("Contacts (never flag people you know)", perm(Manifest.permission.READ_CONTACTS)) { ask(Manifest.permission.READ_CONTACTS) },
        Step("WhatsApp / Telegram messages", Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners")?.contains(ctx.packageName) == true) { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
        Step("Keep running in background", ctx.getSystemService(android.os.PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)) { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) })
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp).clip(RoundedCornerShape(14.dp)).background(CardC).padding(12.dp)) {
        Text("Setup: ${steps.count { it.ok }}/${steps.size} ready", color = Ink, fontWeight = FontWeight.Bold)
        steps.forEach { s -> Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(if (s.ok) "✅ " else "⭕ ", fontSize = 14.sp); Text(s.label, Modifier.weight(1f), Ink, 13.sp)
            if (!s.ok) TextButton({ s.fix() }) { Text("Fix", color = Blue) } } }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Switch greyed out? App info > ⋮ > Allow restricted settings", Modifier.weight(1f), Color.Gray, 11.sp)
            TextButton({ ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))) }) { Text("Open", color = Blue) } }
    }
}
